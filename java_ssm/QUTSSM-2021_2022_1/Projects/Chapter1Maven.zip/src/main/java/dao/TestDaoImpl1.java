package dao;

public class TestDaoImpl1 implements TestDao{
	@Override
	public void sayHello() {
		System.out.println("Hello, Study hard!!!");
	}
}
