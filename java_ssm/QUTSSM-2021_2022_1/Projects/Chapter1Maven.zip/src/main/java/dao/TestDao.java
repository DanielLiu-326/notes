package dao;
public interface TestDao {
	public void sayHello();
}
