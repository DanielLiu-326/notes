package dynamic.jdk;
public interface TestDao {
	public int save(String arg1);
	public void modify();
	public void delete();
}
