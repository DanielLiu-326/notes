package annotation.dao;
public interface TestDao {
	public void save();
}
