package annotation.service;
public interface TestService {
	public void save();
}
