package testH;

public class Father {
    private String money = "privateString";

    public String getMoney() {
        return money;
    }
}
