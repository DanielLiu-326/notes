package testH;

public class Son extends Father {
        public static void main(String[] args) {
        Son s = new Son();
        System.out.println(s.getMoney());
    }
}
