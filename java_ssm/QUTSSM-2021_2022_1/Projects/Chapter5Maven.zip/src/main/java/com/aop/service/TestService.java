package com.aop.service;
public interface TestService {
	public int save(String sql, Object param[]);
	public int delete(String sql, Object param[]);
	public void test();
}

