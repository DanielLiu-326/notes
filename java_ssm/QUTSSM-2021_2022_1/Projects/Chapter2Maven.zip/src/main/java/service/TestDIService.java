package service;

public interface TestDIService {
	public void sayHello();
}
